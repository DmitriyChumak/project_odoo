# models/__init__.py

from . import person
from . import disease
from . import visit
from . import diagnosis
from . import doctor
from . import patient
from . import specialization


