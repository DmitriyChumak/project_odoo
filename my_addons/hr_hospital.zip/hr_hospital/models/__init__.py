# models/__init__.py

from . import person
from . import disease
from . import visit
from . import diagnosis
from . import doctor
from . import patient
from . import specialization
from . import patient_personal_doctor_wizard
from . import disease_report_wizard


